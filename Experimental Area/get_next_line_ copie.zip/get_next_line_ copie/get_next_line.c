/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adebray <adebray@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/04 21:12:06 by adebray           #+#    #+#             */
/*   Updated: 2013/12/04 22:34:41 by adebray          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*ft_strnjoin(char const *s1, char const *s2, int n)
{
	char	*tmp;
	char	*ptr;

	if (s1 != NULL && s2 != NULL)
	{
		tmp = malloc(sizeof(char) * (ft_strlen(s1) + n + 1));
		if (!s2)
			return (NULL);
		ptr = tmp;
		while (*s1)
			*tmp++ = *s1++;
		while (n--)
			*tmp++ = *s2++;
		*tmp = '\0';
		return (ptr);
	}
	return (NULL);
}

int 	get_next_line(int const fd, char **line)
{
	static char	*array;
	char		buffer[BUFF_SIZE];

	if (!array)
	{
		array = ft_memalloc(1);
		while (read(fd, buffer, BUFF_SIZE) > 0)
			array = ft_strjoin(array, buffer);
	}
	*line = ft_strsub(array, 0, ft_strlen(array));
	ft_putendl(*line);
	return (0);
}
